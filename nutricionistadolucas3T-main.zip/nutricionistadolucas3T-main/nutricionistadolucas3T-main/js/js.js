//muda  nome a partir do seletor de classe
var pacientes = document.querySelector(".subtitulo");
pacientes.textContent = "Meus pacientes";
var Aparecida = document.querySelector(".titulo");
Aparecida.textContent = "Kobe Nutrição";

//acessar a tag tr - paciente paulo
var paciente = document.querySelector("#primeiro-cliente");

//seleciona o conteudo peso da tag
var tdPeso = paciente.querySelector(".info-peso");
var peso = tdPeso.textContent;

var tdAltura = paciente.querySelector(".info-altura");
var altura = tdAltura.textContent;

var imc = peso / (altura * altura);

//variaveis com valor true
var pesoValido = true;
var alturaValida = true;

if(peso < 0 || peso > 1000){
    alert("brutal, sobrou só o osso pro betinha");   
    var pesoValido = false;
}
if(altura < 100 || altura > 3.00){
    alert("krai lebrao james de caxias?");
    var alturaValida = false;
}
if(pesoValido && alturaValida){
    //acessar e alterar o imc
var tdImc = paciente.querySelector(".info-imc");
tdImc.textContent = imc;
}